# CubeMate - Rubik's Cube Assistant

## Overview

CubeMate is a client-side Rubik's Cube solving assistant built with React, Three.js, and modern web technologies. The application features a realistic 3D cube visualization, multiple solving methods, interactive learning modes, and comprehensive playback controls. It provides both a distraction-free solving interface and an educational learning platform with algorithm libraries and step-by-step tutorials.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The application follows a component-based React architecture with TypeScript support:

- **UI Framework**: React 18 with modern hooks (useState, useEffect, useRef)
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: Custom hooks pattern with centralized cube state management via `useCubeState`
- **Styling**: Tailwind CSS with shadcn/ui components for consistent design system
- **3D Visualization**: Three.js integration for realistic cube rendering and animations

### Component Structure
- **Core Pages**: Single-page application with cube assistant as main interface
- **UI Components**: Modular shadcn/ui components for consistent interface elements
- **Cube Components**: Specialized components for cube visualization, color picker, method selector, and playback controls
- **Custom Hooks**: Centralized state management and mobile detection utilities

### 3D Rendering System
- **Three.js Integration**: Direct Three.js usage for optimal performance and control
- **Cube Visualization**: Real-time 3D cube with interactive orbit controls
- **Animation System**: Smooth move animations with highlighting and visual feedback
- **Face Interaction**: Click-to-select faces for color customization

### Data Architecture
- **Cube State Management**: Comprehensive cube state tracking with validation
- **Solving Algorithms**: Multiple solving methods (Beginner, CFOP, Roux, ZZ, Kociemba)
- **Algorithm Library**: Extensive collection of cubing algorithms with difficulty ratings
- **Playback System**: Step-by-step solution playback with manual and automatic modes

### Build System
- **Vite**: Modern build tool with hot module replacement
- **TypeScript**: Full type safety across the application
- **Module System**: ESM modules with proper import/export structure
- **Asset Management**: Static asset handling with alias support

## External Dependencies

### UI and Styling
- **@radix-ui/react-***: Comprehensive UI component primitives for accessibility
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Type-safe component variants
- **lucide-react**: Icon library

### 3D Graphics
- **three**: Core 3D graphics library
- **@types/three**: TypeScript definitions for Three.js

### State and Data Management
- **@tanstack/react-query**: Server state management and caching
- **react-hook-form**: Form handling with validation
- **@hookform/resolvers**: Form validation resolvers

### Development Tools
- **vite**: Build tool and development server
- **typescript**: Static type checking
- **@replit/vite-plugin-runtime-error-modal**: Development error overlay

### Database (Prepared but Not Used)
- **drizzle-orm**: Database ORM with PostgreSQL support
- **@neondatabase/serverless**: Serverless PostgreSQL database connection
- **drizzle-zod**: Database schema validation

The application is designed as a fully client-side solution with no backend requirements for core functionality, though database infrastructure is prepared for future features like user accounts or saved configurations.