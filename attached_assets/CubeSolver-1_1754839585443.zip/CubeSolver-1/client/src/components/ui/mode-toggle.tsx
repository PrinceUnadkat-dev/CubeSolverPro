import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface ModeToggleProps {
  mode: 'solve' | 'learn';
  onModeChange: (mode: 'solve' | 'learn') => void;
  className?: string;
}

export function ModeToggle({ mode, onModeChange, className }: ModeToggleProps) {
  return (
    <div className={cn("flex bg-muted rounded-lg p-1", className)}>
      <Button
        variant={mode === 'solve' ? 'default' : 'ghost'}
        size="sm"
        onClick={() => onModeChange('solve')}
        className={cn(
          "flex-1 text-sm font-medium transition-all",
          mode === 'solve' 
            ? "bg-accent-cyan text-dark-primary hover:bg-accent-cyan/90" 
            : "text-muted-foreground hover:text-foreground"
        )}
      >
        <i className="fas fa-play mr-2" />
        Solve Mode
      </Button>
      <Button
        variant={mode === 'learn' ? 'default' : 'ghost'}
        size="sm"
        onClick={() => onModeChange('learn')}
        className={cn(
          "flex-1 text-sm font-medium transition-all",
          mode === 'learn' 
            ? "bg-accent-cyan text-dark-primary hover:bg-accent-cyan/90" 
            : "text-muted-foreground hover:text-foreground"
        )}
      >
        <i className="fas fa-graduation-cap mr-2" />
        Learn Mode
      </Button>
    </div>
  );
}
