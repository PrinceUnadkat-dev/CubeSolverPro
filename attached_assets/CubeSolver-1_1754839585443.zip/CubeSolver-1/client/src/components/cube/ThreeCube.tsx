import { useEffect, useRef, useState } from 'react';
import { CubeState, CubeMove } from '@/types/cube';

interface ThreeCubeProps {
  cubeState: CubeState;
  onFaceClick?: (face: string) => void;
  onLayerRotate?: (move: CubeMove) => void;
  highlightMove?: CubeMove | null;
  className?: string;
}

export function ThreeCube({ 
  cubeState, 
  onFaceClick, 
  onLayerRotate, 
  highlightMove,
  className 
}: ThreeCubeProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isLoading, setIsLoading] = useState(true);
  const sceneRef = useRef<any>(null);
  const rendererRef = useRef<any>(null);
  const cameraRef = useRef<any>(null);
  const cubeGroupRef = useRef<any>(null);
  const controlsRef = useRef<any>(null);

  useEffect(() => {
    if (!canvasRef.current) return;

    let mounted = true;

    const initThreeJS = async () => {
      try {
        // Dynamically import Three.js modules
        const THREE = await import('three');
        const { OrbitControls } = await import('three/examples/jsm/controls/OrbitControls.js');

        if (!mounted) return;

        const canvas = canvasRef.current!;
        const rect = canvas.getBoundingClientRect();

        // Scene setup
        const scene = new THREE.Scene();
        scene.background = new THREE.Color(0x0f0f23); // Dark background
        sceneRef.current = scene;

        // Camera setup
        const camera = new THREE.PerspectiveCamera(
          75,
          rect.width / rect.height,
          0.1,
          1000
        );
        camera.position.set(5, 5, 5);
        camera.lookAt(0, 0, 0);
        cameraRef.current = camera;

        // Renderer setup
        const renderer = new THREE.WebGLRenderer({
          canvas,
          antialias: true,
          alpha: true,
        });
        renderer.setSize(rect.width, rect.height);
        renderer.setPixelRatio(window.devicePixelRatio);
        renderer.shadowMap.enabled = true;
        renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        rendererRef.current = renderer;

        // Lighting setup
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
        scene.add(ambientLight);

        const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
        directionalLight.position.set(10, 10, 5);
        directionalLight.castShadow = true;
        directionalLight.shadow.mapSize.width = 2048;
        directionalLight.shadow.mapSize.height = 2048;
        scene.add(directionalLight);

        // Orbit controls
        const controls = new OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;
        controls.dampingFactor = 0.05;
        controls.enableZoom = true;
        controls.enablePan = false;
        controls.minDistance = 3;
        controls.maxDistance = 15;
        controlsRef.current = controls;

        // Create cube group
        const cubeGroup = new THREE.Group();
        scene.add(cubeGroup);
        cubeGroupRef.current = cubeGroup;

        // Create the Rubik's cube
        createRubiksCube(THREE, cubeGroup, cubeState);

        // Handle window resize
        const handleResize = () => {
          if (!mounted) return;
          const rect = canvas.getBoundingClientRect();
          camera.aspect = rect.width / rect.height;
          camera.updateProjectionMatrix();
          renderer.setSize(rect.width, rect.height);
        };

        window.addEventListener('resize', handleResize);

        // Animation loop
        const animate = () => {
          if (!mounted) return;
          
          requestAnimationFrame(animate);
          controls.update();
          renderer.render(scene, camera);
        };
        animate();

        setIsLoading(false);

        return () => {
          window.removeEventListener('resize', handleResize);
          controls.dispose();
          renderer.dispose();
        };

      } catch (error) {
        console.error('Failed to initialize Three.js:', error);
        setIsLoading(false);
      }
    };

    initThreeJS();

    return () => {
      mounted = false;
    };
  }, []);

  // Update cube when state changes
  useEffect(() => {
    if (!cubeGroupRef.current || isLoading) return;

    const THREE = (window as any).THREE;
    if (!THREE) return;

    // Clear existing cube
    while (cubeGroupRef.current.children.length > 0) {
      cubeGroupRef.current.remove(cubeGroupRef.current.children[0]);
    }

    // Create new cube with updated state
    createRubiksCube(THREE, cubeGroupRef.current, cubeState);
  }, [cubeState, isLoading]);

  const createRubiksCube = (THREE: any, group: any, state: CubeState) => {
    const cubeSize = 0.9;
    const gap = 0.05;
    const stickers = [];

    // Define face colors and positions
    const faceConfigs = [
      { face: 'front', normal: [0, 0, 1], colors: state.faces.front },
      { face: 'back', normal: [0, 0, -1], colors: state.faces.back },
      { face: 'right', normal: [1, 0, 0], colors: state.faces.right },
      { face: 'left', normal: [-1, 0, 0], colors: state.faces.left },
      { face: 'top', normal: [0, 1, 0], colors: state.faces.top },
      { face: 'bottom', normal: [0, -1, 0], colors: state.faces.bottom },
    ];

    // Create each face
    faceConfigs.forEach(({ face, normal, colors }) => {
      for (let row = 0; row < 3; row++) {
        for (let col = 0; col < 3; col++) {
          const color = colors[row][col];
          const sticker = createSticker(THREE, color, face, row, col, normal, cubeSize, gap);
          stickers.push(sticker);
          group.add(sticker);
        }
      }
    });

    // Add click interaction
    if (onFaceClick) {
      addClickInteraction(THREE, group, stickers, onFaceClick);
    }
  };

  const createSticker = (
    THREE: any,
    color: string,
    face: string,
    row: number,
    col: number,
    normal: number[],
    cubeSize: number,
    gap: number
  ) => {
    const geometry = new THREE.PlaneGeometry(cubeSize - gap, cubeSize - gap);
    const material = new THREE.MeshLambertMaterial({ 
      color: new THREE.Color(color),
      transparent: true,
      opacity: 0.9
    });
    
    const sticker = new THREE.Mesh(geometry, material);
    
    // Position the sticker
    const offset = cubeSize + gap * 0.5;
    const positions = [
      (col - 1) * offset,
      -(row - 1) * offset,
      0
    ];

    // Apply face transformations
    switch (face) {
      case 'front':
        sticker.position.set(positions[0], positions[1], offset);
        break;
      case 'back':
        sticker.position.set(-positions[0], positions[1], -offset);
        sticker.rotateY(Math.PI);
        break;
      case 'right':
        sticker.position.set(offset, positions[1], -positions[0]);
        sticker.rotateY(Math.PI / 2);
        break;
      case 'left':
        sticker.position.set(-offset, positions[1], positions[0]);
        sticker.rotateY(-Math.PI / 2);
        break;
      case 'top':
        sticker.position.set(positions[0], offset, -positions[1]);
        sticker.rotateX(-Math.PI / 2);
        break;
      case 'bottom':
        sticker.position.set(positions[0], -offset, positions[1]);
        sticker.rotateX(Math.PI / 2);
        break;
    }

    // Add border
    const borderGeometry = new THREE.EdgesGeometry(geometry);
    const borderMaterial = new THREE.LineBasicMaterial({ color: 0x000000, linewidth: 2 });
    const border = new THREE.LineSegments(borderGeometry, borderMaterial);
    sticker.add(border);

    // Store metadata
    sticker.userData = { face, row, col };

    return sticker;
  };

  const addClickInteraction = (THREE: any, group: any, stickers: any[], onFaceClick: (face: string) => void) => {
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    const handleClick = (event: MouseEvent) => {
      if (!canvasRef.current || !cameraRef.current) return;

      const rect = canvasRef.current.getBoundingClientRect();
      mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(mouse, cameraRef.current);
      const intersects = raycaster.intersectObjects(stickers);

      if (intersects.length > 0) {
        const sticker = intersects[0].object;
        if (sticker.userData?.face) {
          onFaceClick(sticker.userData.face);
        }
      }
    };

    canvasRef.current?.addEventListener('click', handleClick);
  };

  if (isLoading) {
    return (
      <div className={`flex items-center justify-center bg-dark-primary rounded-lg ${className}`}>
        <div className="flex flex-col items-center space-y-4">
          <div className="animate-spin rounded-full h-12 w-12 border-4 border-accent-cyan border-t-transparent"></div>
          <p className="text-muted-foreground text-sm">Loading 3D Cube...</p>
        </div>
      </div>
    );
  }

  return (
    <div className={`relative bg-dark-primary rounded-lg overflow-hidden ${className}`}>
      <canvas
        ref={canvasRef}
        className="w-full h-full cube-canvas"
        style={{ minHeight: '400px' }}
      />
      
      {/* Controls Overlay */}
      <div className="absolute top-4 left-4 bg-dark-secondary/80 backdrop-blur-sm rounded-lg p-3">
        <div className="text-xs text-muted-foreground mb-1">Controls</div>
        <div className="text-xs text-foreground space-y-1">
          <div><i className="fas fa-mouse-pointer mr-2 text-accent-cyan" />Drag to rotate</div>
          <div><i className="fas fa-scroll mr-2 text-accent-cyan" />Scroll to zoom</div>
          <div><i className="fas fa-hand-pointer mr-2 text-accent-cyan" />Click face to select</div>
        </div>
      </div>

      {/* Current Move Display */}
      {highlightMove && (
        <div className="absolute top-4 right-4 bg-dark-secondary/80 backdrop-blur-sm rounded-lg p-3">
          <div className="text-xs text-muted-foreground mb-1">Current Move</div>
          <div className="text-lg font-bold text-accent-cyan">{highlightMove.notation}</div>
          <div className="text-xs text-muted-foreground">{highlightMove.description}</div>
        </div>
      )}
    </div>
  );
}
