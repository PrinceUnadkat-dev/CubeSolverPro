import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { SolvingMethod } from '@/types/cube';
import { cn } from '@/lib/utils';

interface MethodSelectorProps {
  selectedMethod: SolvingMethod;
  onMethodChange: (method: SolvingMethod) => void;
  mode: 'solve' | 'learn';
}

const SOLVING_METHODS = [
  {
    id: 'beginner' as SolvingMethod,
    name: 'Beginner Method',
    description: 'Layer-by-layer approach',
    icon: 'fas fa-graduation-cap',
    difficulty: 'Easy',
    avgMoves: '50-100',
    color: 'accent-mint',
    details: 'Perfect for beginners. Teaches fundamental concepts and builds intuition.'
  },
  {
    id: 'cfop' as SolvingMethod,
    name: 'CFOP Method',
    description: 'Cross, F2L, OLL, PLL',
    icon: 'fas fa-bolt',
    difficulty: 'Hard',
    avgMoves: '50-60',
    color: 'accent-orange',
    details: 'Most popular speedcubing method. Fast but requires memorizing many algorithms.'
  },
  {
    id: 'roux' as SolvingMethod,
    name: 'Roux Method',
    description: 'Block building approach',
    icon: 'fas fa-cubes',
    difficulty: 'Medium',
    avgMoves: '45-50',
    color: 'accent-purple',
    details: 'Intuitive block-building method with fewer algorithms to memorize.'
  },
  {
    id: 'zz' as SolvingMethod,
    name: 'ZZ Method',
    description: 'Edge orientation first',
    icon: 'fas fa-puzzle-piece',
    difficulty: 'Hard',
    avgMoves: '50-55',
    color: 'accent-coral',
    details: 'Reduces cube rotations. Good for one-handed solving.'
  },
  {
    id: 'kociemba' as SolvingMethod,
    name: 'Kociemba Algorithm',
    description: 'Optimal computer solution',
    icon: 'fas fa-microchip',
    difficulty: 'Auto',
    avgMoves: '19-25',
    color: 'accent-cyan',
    details: 'Computer-generated optimal solution. Great for learning optimal move sequences.'
  }
];

export function MethodSelector({ selectedMethod, onMethodChange, mode }: MethodSelectorProps) {
  return (
    <RadioGroup 
      value={selectedMethod} 
      onValueChange={(value) => onMethodChange(value as SolvingMethod)}
      className="space-y-2"
    >
      {SOLVING_METHODS.map((method) => (
        <div 
          key={method.id}
          className={cn(
            "p-2 rounded border transition-all cursor-pointer",
            selectedMethod === method.id 
              ? "border-accent-cyan bg-accent-cyan/10" 
              : "border-border hover:border-accent-cyan/50"
          )}
        >
          <div className="flex items-center space-x-2">
            <RadioGroupItem value={method.id} id={method.id} className="text-accent-cyan" />
            <Label htmlFor={method.id} className="flex-1 cursor-pointer">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <i className={`${method.icon} text-${method.color} text-xs`} />
                  <span className="text-sm font-medium text-foreground">{method.name}</span>
                </div>
                <Badge 
                  variant="outline" 
                  className={cn(
                    "text-xs",
                    method.difficulty === 'Easy' && "border-accent-mint text-accent-mint",
                    method.difficulty === 'Medium' && "border-accent-orange text-accent-orange", 
                    method.difficulty === 'Hard' && "border-accent-coral text-accent-coral",
                    method.difficulty === 'Auto' && "border-accent-cyan text-accent-cyan"
                  )}
                >
                  {method.difficulty}
                </Badge>
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                {method.description} • {method.avgMoves} moves
              </div>
              {mode === 'learn' && selectedMethod === method.id && (
                <div className="text-xs text-muted-foreground italic mt-1 p-2 bg-muted/20 rounded">
                  {method.details}
                </div>
              )}
            </Label>
          </div>
        </div>
      ))}
    </RadioGroup>
  );
}
