import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { AlgorithmCase } from '@/types/cube';
import { cn } from '@/lib/utils';

interface AlgorithmCardProps {
  algorithm: AlgorithmCase;
  isActive?: boolean;
  onSelect: (algorithm: AlgorithmCase) => void;
  className?: string;
}

export function AlgorithmCard({ 
  algorithm, 
  isActive = false, 
  onSelect, 
  className 
}: AlgorithmCardProps) {
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy':
        return 'accent-mint';
      case 'medium':
        return 'accent-orange';
      case 'hard':
        return 'accent-coral';
      default:
        return 'accent-cyan';
    }
  };

  const difficultyColor = getDifficultyColor(algorithm.difficulty || 'medium');

  return (
    <Card 
      className={cn(
        "algorithm-card transition-all cursor-pointer hover:scale-[1.02]",
        isActive && "border-accent-cyan bg-accent-cyan/10 glow-cyan",
        className
      )}
      onClick={() => onSelect(algorithm)}
    >
      <CardContent className="p-4">
        <div className="space-y-3">
          {/* Header */}
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <h4 className="font-semibold text-foreground text-sm leading-tight">
                {algorithm.name}
              </h4>
              {algorithm.pattern && (
                <p className="text-xs text-muted-foreground mt-1">
                  {algorithm.pattern}
                </p>
              )}
            </div>
            
            <div className="flex flex-col items-end space-y-1 ml-2">
              {algorithm.difficulty && (
                <Badge 
                  variant="outline" 
                  className={cn(
                    "text-xs border",
                    `border-${difficultyColor} text-${difficultyColor}`
                  )}
                >
                  {algorithm.difficulty}
                </Badge>
              )}
              {algorithm.probability && (
                <span className="text-xs text-muted-foreground">
                  {(algorithm.probability * 100).toFixed(1)}%
                </span>
              )}
            </div>
          </div>

          {/* Algorithm Display */}
          <div className="bg-muted/50 rounded-lg p-3 border border-border/50">
            <div className="text-xs text-muted-foreground mb-1">Algorithm:</div>
            <div className="font-mono text-sm text-accent-cyan leading-relaxed break-all">
              {algorithm.algorithm}
            </div>
          </div>

          {/* Move Count and Timing */}
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>{algorithm.algorithm.split(' ').length} moves</span>
            {isActive && (
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-accent-cyan rounded-full animate-pulse" />
                <span className="text-accent-cyan">Active</span>
              </div>
            )}
          </div>

          {/* Action Button */}
          <Button
            variant="outline"
            size="sm"
            className={cn(
              "w-full text-xs transition-all",
              isActive 
                ? "border-accent-cyan text-accent-cyan hover:bg-accent-cyan/20" 
                : "hover:border-accent-cyan/50 hover:text-accent-cyan"
            )}
            onClick={(e) => {
              e.stopPropagation();
              onSelect(algorithm);
            }}
          >
            <i className="fas fa-play mr-2" />
            {isActive ? 'Currently Active' : 'Practice Algorithm'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
