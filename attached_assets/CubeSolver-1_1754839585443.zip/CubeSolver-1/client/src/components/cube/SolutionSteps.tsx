import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Solution, SolutionStep, PlaybackState } from '@/types/cube';
import { cn } from '@/lib/utils';

interface SolutionStepsProps {
  solution: Solution | null;
  playbackState: PlaybackState;
  mode: 'solve' | 'learn';
  onStepSelect?: (stepIndex: number) => void;
  onMoveSelect?: (stepIndex: number, moveIndex: number) => void;
}

export function SolutionSteps({
  solution,
  playbackState,
  mode,
  onStepSelect,
  onMoveSelect
}: SolutionStepsProps) {
  const [expandedSteps, setExpandedSteps] = useState<Set<number>>(new Set([0]));
  const [isExpanded, setIsExpanded] = useState(false);

  const toggleStep = (stepIndex: number) => {
    const newExpanded = new Set(expandedSteps);
    if (newExpanded.has(stepIndex)) {
      newExpanded.delete(stepIndex);
    } else {
      newExpanded.add(stepIndex);
    }
    setExpandedSteps(newExpanded);
  };

  const toggleExpandAll = () => {
    if (isExpanded && solution) {
      setExpandedSteps(new Set());
    } else if (solution) {
      setExpandedSteps(new Set(Array.from({ length: solution.steps.length }, (_, i) => i)));
    }
    setIsExpanded(!isExpanded);
  };

  if (!solution) {
    return (
      <Card className="bg-dark-secondary border-border h-full">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-medium text-foreground">Solution Steps</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="bg-muted rounded-lg p-6 text-center">
            <i className="fas fa-cube text-4xl text-muted-foreground mb-3" />
            <div className="text-sm text-muted-foreground mb-2">No solution generated</div>
            <div className="text-xs text-muted-foreground">
              Configure colors and click "Solve Cube" to begin
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-dark-secondary border-border h-full flex flex-col">
      <CardHeader className="flex-shrink-0">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-medium text-foreground">Solution Steps</CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleExpandAll}
            className="text-accent-cyan hover:text-accent-cyan/80 text-xs"
          >
            <i className={`fas ${isExpanded ? 'fa-compress-alt' : 'fa-expand-alt'} mr-1`} />
            {isExpanded ? 'Collapse' : 'Expand'}
          </Button>
        </div>
        
        {/* Solution Summary */}
        <div className="grid grid-cols-2 gap-4 mt-2">
          <div className="text-center">
            <div className="text-xs text-muted-foreground">Total Moves</div>
            <div className="text-lg font-bold text-accent-cyan">{solution.totalMoves}</div>
          </div>
          <div className="text-center">
            <div className="text-xs text-muted-foreground">Est. Time</div>
            <div className="text-lg font-bold text-accent-orange">
              {Math.round(solution.estimatedTime)}s
            </div>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="flex-1 overflow-hidden p-0">
        <ScrollArea className="h-full p-6">
          <div className="space-y-3">
            {solution.steps.map((step, stepIndex) => (
              <StepCard
                key={stepIndex}
                step={step}
                stepIndex={stepIndex}
                isExpanded={expandedSteps.has(stepIndex)}
                isCurrent={playbackState.currentStep === stepIndex}
                currentMoveIndex={playbackState.currentStep === stepIndex ? playbackState.currentMove : -1}
                mode={mode}
                onToggle={() => toggleStep(stepIndex)}
                onStepSelect={() => onStepSelect?.(stepIndex)}
                onMoveSelect={(moveIndex) => onMoveSelect?.(stepIndex, moveIndex)}
              />
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}

interface StepCardProps {
  step: SolutionStep;
  stepIndex: number;
  isExpanded: boolean;
  isCurrent: boolean;
  currentMoveIndex: number;
  mode: 'solve' | 'learn';
  onToggle: () => void;
  onStepSelect: () => void;
  onMoveSelect: (moveIndex: number) => void;
}

function StepCard({
  step,
  stepIndex,
  isExpanded,
  isCurrent,
  currentMoveIndex,
  mode,
  onToggle,
  onStepSelect,
  onMoveSelect
}: StepCardProps) {
  const phaseColors = {
    'White Cross': 'accent-mint',
    'White Corners': 'accent-cyan',
    'Middle Layer Edges': 'accent-orange',
    'Yellow Cross': 'accent-purple',
    'Yellow Face': 'accent-coral',
    'Position Yellow Corners': 'accent-mint',
    'Position Yellow Edges': 'accent-cyan',
    'Cross': 'accent-mint',
    'F2L': 'accent-cyan',
    'OLL': 'accent-orange',
    'PLL': 'accent-purple',
    'First Block': 'accent-mint',
    'Second Block': 'accent-cyan',
    'CMLL': 'accent-orange',
    'LSE': 'accent-purple',
    'EOLine': 'accent-mint',
    'ZBLL': 'accent-orange',
    'Phase 1': 'accent-cyan',
    'Phase 2': 'accent-orange'
  };

  const getPhaseColor = (phase: string) => {
    const colorKey = Object.keys(phaseColors).find(key => phase.includes(key));
    return colorKey ? phaseColors[colorKey as keyof typeof phaseColors] : 'accent-cyan';
  };

  const phaseColor = getPhaseColor(step.phase);

  return (
    <Collapsible open={isExpanded} onOpenChange={onToggle}>
      <div className={cn(
        "border rounded-lg transition-all hover:border-accent-cyan/50",
        isCurrent ? `border-${phaseColor} bg-${phaseColor}/5` : "border-border"
      )}>
        <CollapsibleTrigger asChild>
          <Button
            variant="ghost"
            className="w-full p-3 h-auto justify-between hover:bg-transparent"
          >
            <div className="flex items-center space-x-3">
              <Badge 
                variant="outline" 
                className={cn(
                  "text-xs",
                  isCurrent 
                    ? `border-${phaseColor} text-${phaseColor}` 
                    : "border-muted-foreground text-muted-foreground"
                )}
              >
                {stepIndex + 1}
              </Badge>
              <div className="text-left">
                <div className={cn(
                  "font-medium",
                  isCurrent ? `text-${phaseColor}` : "text-foreground"
                )}>
                  {step.phase}
                </div>
                <div className="text-xs text-muted-foreground">
                  {step.moves.length} moves
                </div>
              </div>
            </div>
            <i className={`fas fa-chevron-${isExpanded ? 'up' : 'down'} text-muted-foreground`} />
          </Button>
        </CollapsibleTrigger>

        <CollapsibleContent>
          <div className="px-3 pb-3 space-y-3">
            {/* Step Explanation (Learn Mode) */}
            {mode === 'learn' && step.explanation && (
              <div className="text-xs text-muted-foreground p-2 bg-muted/50 rounded">
                <strong>Goal:</strong> {step.explanation}
              </div>
            )}

            {/* Algorithm Display (Learn Mode) */}
            {mode === 'learn' && step.algorithm && (
              <div className="algorithm-card rounded-lg p-3">
                <div className="text-xs text-muted-foreground mb-1">Algorithm:</div>
                <div className="font-mono text-sm text-accent-cyan">
                  {step.algorithm}
                </div>
              </div>
            )}

            {/* Move List */}
            <div className="grid grid-cols-6 gap-1">
              {step.moves.map((move, moveIndex) => (
                <Button
                  key={moveIndex}
                  variant="outline"
                  size="sm"
                  onClick={() => onMoveSelect(moveIndex)}
                  className={cn(
                    "h-8 p-1 text-xs font-mono transition-all",
                    isCurrent && moveIndex === currentMoveIndex
                      ? `border-${phaseColor} bg-${phaseColor}/20 text-${phaseColor}`
                      : isCurrent && moveIndex < currentMoveIndex
                      ? "border-accent-mint/50 bg-accent-mint/10 text-accent-mint"
                      : "border-border hover:border-accent-cyan/50"
                  )}
                >
                  {move.notation}
                </Button>
              ))}
            </div>

            {/* Step Progress */}
            {isCurrent && (
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span>Progress: {currentMoveIndex} / {step.moves.length}</span>
                <div className="w-16 h-1 bg-muted rounded-full overflow-hidden">
                  <div 
                    className={`h-full bg-${phaseColor} transition-all duration-300`}
                    style={{ 
                      width: `${(currentMoveIndex / step.moves.length) * 100}%` 
                    }}
                  />
                </div>
              </div>
            )}
          </div>
        </CollapsibleContent>
      </div>
    </Collapsible>
  );
}
