import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { PlaybackState, CubeMove } from '@/types/cube';
import { cn } from '@/lib/utils';

interface PlaybackControlsProps {
  playbackState: PlaybackState;
  onPlaybackChange: (settings: Partial<PlaybackState>) => void;
  onNextMove: () => void;
  onPreviousMove: () => void;
  onTogglePlay: () => void;
  currentMove: CubeMove | null;
  progress: { current: number; total: number; percentage: number };
  mode: 'solve' | 'learn';
}

export function PlaybackControls({
  playbackState,
  onPlaybackChange,
  onNextMove,
  onPreviousMove,
  onTogglePlay,
  currentMove,
  progress,
  mode
}: PlaybackControlsProps) {
  const isManualMode = !playbackState.isPlaying;
  const hasProgress = progress.total > 0;
  const canGoBack = progress.current > 0;
  const canGoForward = progress.current < progress.total;

  return (
    <Card className="bg-dark-secondary border-border">
      <CardHeader>
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center text-muted-foreground font-bold text-sm">
            3
          </div>
          <CardTitle className="text-lg text-foreground">Playback Controls</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Playback Mode Toggle */}
        <div>
          <div className="flex bg-muted rounded-lg p-1 mb-4">
            <Button
              variant={isManualMode ? 'default' : 'ghost'}
              size="sm"
              onClick={() => onPlaybackChange({ isPlaying: false })}
              className={cn(
                "flex-1 text-sm font-medium transition-all",
                isManualMode 
                  ? "bg-accent-cyan text-dark-primary hover:bg-accent-cyan/90" 
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              Manual
            </Button>
            <Button
              variant={!isManualMode ? 'default' : 'ghost'}
              size="sm"
              onClick={onTogglePlay}
              className={cn(
                "flex-1 text-sm font-medium transition-all",
                !isManualMode 
                  ? "bg-accent-cyan text-dark-primary hover:bg-accent-cyan/90" 
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              Auto
            </Button>
          </div>
        </div>

        {/* Manual Controls */}
        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-2">
            <Button
              variant="outline"
              onClick={onPreviousMove}
              disabled={!canGoBack}
              className="text-foreground hover:text-accent-cyan hover:border-accent-cyan"
            >
              <i className="fas fa-step-backward" />
            </Button>
            <Button
              variant="default"
              onClick={isManualMode ? onNextMove : onTogglePlay}
              disabled={isManualMode && !canGoForward}
              className="bg-accent-cyan text-dark-primary hover:bg-accent-cyan/90 font-semibold"
            >
              {isManualMode ? (
                <>
                  <i className="fas fa-step-forward mr-1" />
                  Next
                </>
              ) : (
                <>
                  <i className={`fas ${playbackState.isPlaying ? 'fa-pause' : 'fa-play'} mr-1`} />
                  {playbackState.isPlaying ? 'Pause' : 'Play'}
                </>
              )}
            </Button>
            <Button
              variant="outline"
              onClick={() => onPlaybackChange({ currentStep: 0, currentMove: 0, isPlaying: false })}
              className="text-foreground hover:text-accent-coral hover:border-accent-coral"
            >
              <i className="fas fa-undo" />
            </Button>
          </div>

          {/* Progress Bar */}
          {hasProgress && (
            <div className="bg-muted rounded-lg p-4">
              <div className="flex justify-between text-xs text-muted-foreground mb-2">
                <span>Progress</span>
                <span>{progress.current} / {progress.total} moves</span>
              </div>
              <Progress value={progress.percentage} className="h-2 bg-muted-foreground/20">
                <div 
                  className="h-full bg-accent-cyan rounded-full transition-all duration-300"
                  style={{ width: `${progress.percentage}%` }}
                />
              </Progress>
            </div>
          )}

          {/* Speed Control */}
          <div className="bg-muted rounded-lg p-4">
            <div className="flex justify-between text-xs text-muted-foreground mb-2">
              <span>Animation Speed</span>
              <span>{playbackState.speed.toFixed(1)}x</span>
            </div>
            <Slider
              value={[playbackState.speed]}
              onValueChange={([speed]) => onPlaybackChange({ speed })}
              min={0.5}
              max={3}
              step={0.1}
              className="speed-slider"
            />
            <div className="flex justify-between text-xs text-muted-foreground mt-1">
              <span>0.5x</span>
              <span>3.0x</span>
            </div>
          </div>

          {/* Display Options */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label htmlFor="show-notation" className="text-sm text-foreground">
                Show notation
              </Label>
              <Switch
                id="show-notation"
                checked={playbackState.showNotation}
                onCheckedChange={(showNotation) => onPlaybackChange({ showNotation })}
              />
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="highlight-moves" className="text-sm text-foreground">
                Highlight moves
              </Label>
              <Switch
                id="highlight-moves"
                checked={playbackState.highlightMoves}
                onCheckedChange={(highlightMoves) => onPlaybackChange({ highlightMoves })}
              />
            </div>
          </div>
        </div>

        {/* Current Move Display */}
        <div className="bg-muted rounded-lg p-4">
          <div className="text-xs text-muted-foreground mb-2">Current Move</div>
          {currentMove ? (
            <div className="text-center">
              <div className="text-2xl font-bold text-accent-cyan mb-1">
                {playbackState.showNotation ? currentMove.notation : '•'}
              </div>
              {mode === 'learn' && (
                <div className="text-xs text-muted-foreground">
                  {currentMove.description}
                </div>
              )}
            </div>
          ) : (
            <div className="text-center">
              <div className="text-2xl font-bold text-muted-foreground mb-1">-</div>
              <div className="text-xs text-muted-foreground">
                {hasProgress ? 'Solution complete!' : 'Generate solution to begin'}
              </div>
            </div>
          )}
        </div>

        {/* Quick Stats (Learn Mode) */}
        {mode === 'learn' && hasProgress && (
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-muted rounded-lg p-3 text-center">
              <div className="text-xs text-muted-foreground mb-1">Steps</div>
              <div className="text-lg font-bold text-accent-mint">
                {playbackState.currentStep + 1}
              </div>
            </div>
            <div className="bg-muted rounded-lg p-3 text-center">
              <div className="text-xs text-muted-foreground mb-1">TPS</div>
              <div className="text-lg font-bold text-accent-orange">
                {playbackState.speed.toFixed(1)}
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
