import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CubeColors, PRESET_COLOR_PALETTES } from '@/types/cube';
import { cn } from '@/lib/utils';

interface ColorPickerProps {
  colors: CubeColors;
  onColorsChange: (colors: CubeColors) => void;
  selectedFace: string | null;
  onFaceSelect: (face: string) => void;
  isValid: boolean;
}

export function ColorPicker({ 
  colors, 
  onColorsChange, 
  selectedFace, 
  onFaceSelect,
  isValid 
}: ColorPickerProps) {
  const handlePresetSelect = (preset: typeof PRESET_COLOR_PALETTES[0]) => {
    onColorsChange(preset.colors);
  };

  const handleColorSelect = (color: string) => {
    if (selectedFace && selectedFace in colors) {
      onColorsChange({
        ...colors,
        [selectedFace]: color
      });
    }
  };

  const cubeColors = ['#ffffff', '#ef4444', '#22c55e', '#3b82f6', '#f97316', '#eab308'];

  return (
    <Card className="bg-dark-secondary border-border">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm text-foreground">Step 1: Set Colors</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Quick Presets */}
        <div>
          <div className="text-xs text-muted-foreground mb-2">Quick Setup:</div>
          <div className="grid grid-cols-2 gap-2">
            {PRESET_COLOR_PALETTES.map((preset) => (
              <Button
                key={preset.name}
                variant="outline"
                onClick={() => handlePresetSelect(preset)}
                className="p-2 h-auto text-xs hover:border-accent-cyan"
                size="sm"
              >
                {preset.name}
              </Button>
            ))}
          </div>
        </div>

        {/* Standard Cube Colors */}
        <div>
          <div className="text-xs text-muted-foreground mb-2">
            {selectedFace ? `Pick color for ${selectedFace} face:` : 'Click a cube face first'}
          </div>
          <div className="grid grid-cols-6 gap-2">
            {cubeColors.map((color) => (
              <button
                key={color}
                onClick={() => handleColorSelect(color)}
                disabled={!selectedFace}
                className={cn(
                  "w-6 h-6 rounded border-2 transition-all",
                  selectedFace ? "cursor-pointer hover:scale-110" : "cursor-not-allowed opacity-50",
                  selectedFace && colors[selectedFace as keyof CubeColors] === color 
                    ? "border-accent-cyan shadow-lg shadow-accent-cyan/50" 
                    : "border-border hover:border-accent-cyan/50"
                )}
                style={{ backgroundColor: color }}
              />
            ))}
          </div>
        </div>

        {/* Face Status */}
        <div className="bg-muted/20 rounded p-2">
          <div className="grid grid-cols-3 gap-1 text-xs">
            {Object.entries(colors).map(([face, color]) => (
              <div key={face} className="flex items-center space-x-1">
                <div 
                  className="w-3 h-3 rounded border border-border"
                  style={{ backgroundColor: color }}
                />
                <span className="text-muted-foreground capitalize">{face}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Validation */}
        {!isValid && (
          <div className="text-xs text-destructive bg-destructive/10 rounded p-2">
            Each face needs a different color
          </div>
        )}
      </CardContent>
    </Card>
  );
}