export type FaceColor = string;

export interface CubeColors {
  front: FaceColor;
  back: FaceColor;
  left: FaceColor;
  right: FaceColor;
  top: FaceColor;
  bottom: FaceColor;
}

export interface CubeState {
  // 3x3x3 cube state representation
  // Each face is a 3x3 array of colors
  faces: {
    front: FaceColor[][];
    back: FaceColor[][];
    left: FaceColor[][];
    right: FaceColor[][];
    top: FaceColor[][];
    bottom: FaceColor[][];
  };
  isScrambled: boolean;
  isSolved: boolean;
}

export type SolvingMethod = 'beginner' | 'cfop' | 'roux' | 'zz' | 'kociemba';

export type AppMode = 'solve' | 'learn';

export interface CubeMove {
  notation: string;
  description: string;
  face: string;
  direction: 'clockwise' | 'counterclockwise' | 'double';
}

export interface SolutionStep {
  phase: string;
  moves: CubeMove[];
  explanation?: string;
  algorithm?: string;
}

export interface Solution {
  method: SolvingMethod;
  steps: SolutionStep[];
  totalMoves: number;
  estimatedTime: number;
}

export interface AlgorithmCase {
  id: string;
  name: string;
  pattern: string;
  algorithm: string;
  probability?: number;
  difficulty?: 'easy' | 'medium' | 'hard';
}

export interface PlaybackState {
  isPlaying: boolean;
  currentStep: number;
  currentMove: number;
  speed: number;
  showNotation: boolean;
  highlightMoves: boolean;
}

export interface CubeConfig {
  colors: CubeColors;
  method: SolvingMethod;
  mode: AppMode;
}

export const DEFAULT_CUBE_COLORS: CubeColors = {
  front: '#22c55e',  // Green
  back: '#3b82f6',   // Blue
  left: '#f97316',   // Orange
  right: '#ef4444',  // Red
  top: '#ffffff',    // White
  bottom: '#eab308', // Yellow
};

export const PRESET_COLOR_PALETTES = [
  {
    name: 'Classic',
    colors: DEFAULT_CUBE_COLORS,
  },
  {
    name: 'Neon',
    colors: {
      front: '#00ff88',
      back: '#0088ff',
      left: '#ff8800',
      right: '#ff0044',
      top: '#ffffff',
      bottom: '#ffff00',
    },
  },
  {
    name: 'Pastel',
    colors: {
      front: '#a7f3d0',
      back: '#bfdbfe',
      left: '#fed7aa',
      right: '#fecaca',
      top: '#f9fafb',
      bottom: '#fef3c7',
    },
  },
];

export const COLOR_PALETTE = [
  '#ffffff', '#ef4444', '#22c55e', '#3b82f6', '#f97316', '#eab308',
  '#8b5cf6', '#ec4899', '#00d4ff', '#ff6b6b', '#4ecdc4', '#6b7280',
];
