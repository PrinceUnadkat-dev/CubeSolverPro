import { CubeState, CubeColors, CubeMove } from '@/types/cube';

export function generateSolvedState(colors: CubeColors): CubeState {
  const createFace = (color: string) => 
    Array(3).fill(null).map(() => Array(3).fill(color));

  return {
    faces: {
      front: createFace(colors.front),
      back: createFace(colors.back),
      left: createFace(colors.left),
      right: createFace(colors.right),
      top: createFace(colors.top),
      bottom: createFace(colors.bottom),
    },
    isScrambled: false,
    isSolved: true,
  };
}

export function generateScrambledState(colors: CubeColors): CubeState {
  // Generate a randomized cube state
  const solvedState = generateSolvedState(colors);
  
  // Apply random moves to scramble
  const scrambleMoves = generateScrambleMoves(20);
  let scrambledState = solvedState;
  
  scrambleMoves.forEach(move => {
    scrambledState = applyCubeMove(scrambledState, move);
  });
  
  return {
    ...scrambledState,
    isScrambled: true,
    isSolved: false,
  };
}

export function generateScrambleMoves(count: number): CubeMove[] {
  const faces = ['R', 'U', 'F', 'L', 'D', 'B'];
  const modifiers = ['', "'", '2'];
  const moves: CubeMove[] = [];
  
  for (let i = 0; i < count; i++) {
    const face = faces[Math.floor(Math.random() * faces.length)];
    const modifier = modifiers[Math.floor(Math.random() * modifiers.length)];
    const notation = face + modifier;
    
    moves.push({
      notation,
      description: `${face} face ${getRotationDescription(modifier)}`,
      face: face.toLowerCase(),
      direction: getDirection(modifier),
    });
  }
  
  return moves;
}

function getRotationDescription(modifier: string): string {
  switch (modifier) {
    case "'": return 'counterclockwise';
    case '2': return 'double turn';
    default: return 'clockwise';
  }
}

function getDirection(modifier: string): 'clockwise' | 'counterclockwise' | 'double' {
  switch (modifier) {
    case "'": return 'counterclockwise';
    case '2': return 'double';
    default: return 'clockwise';
  }
}

export function applyCubeMove(state: CubeState, move: CubeMove): CubeState {
  // This is a simplified implementation
  // In a real application, you would implement proper cube rotation logic
  const newState = JSON.parse(JSON.stringify(state));
  
  // Apply the move transformation
  // This would involve rotating the appropriate face and updating adjacent edges
  // For now, we'll return the state as-is since this requires complex 3D rotation logic
  
  return {
    ...newState,
    isSolved: false,
    isScrambled: true,
  };
}

export function validateCubeState(state: CubeState, colors: CubeColors): boolean {
  // Check if center pieces match the expected colors
  const centerColors = {
    front: state.faces.front[1][1],
    back: state.faces.back[1][1],
    left: state.faces.left[1][1],
    right: state.faces.right[1][1],
    top: state.faces.top[1][1],
    bottom: state.faces.bottom[1][1],
  };
  
  // Ensure no two faces have the same center color
  const uniqueColors = new Set(Object.values(centerColors));
  if (uniqueColors.size !== 6) {
    return false;
  }
  
  // Check if center colors match the configuration
  return Object.keys(colors).every(face => 
    centerColors[face as keyof typeof centerColors] === colors[face as keyof CubeColors]
  );
}

export function isCubeSolved(state: CubeState): boolean {
  // Check if each face has uniform colors
  return Object.values(state.faces).every(face => {
    const centerColor = face[1][1];
    return face.every(row => row.every(cell => cell === centerColor));
  });
}

export function getCubeStateString(state: CubeState): string {
  // Convert cube state to a string representation for solver algorithms
  const faceOrder = ['top', 'right', 'front', 'bottom', 'left', 'back'] as const;
  
  return faceOrder.map(face => 
    state.faces[face].flat().join('')
  ).join('');
}

export function parseCubeStateString(stateString: string, colors: CubeColors): CubeState {
  // Parse a string representation back to cube state
  const faceOrder = ['top', 'right', 'front', 'bottom', 'left', 'back'] as const;
  const faces = {} as any;
  
  faceOrder.forEach((face, faceIndex) => {
    const start = faceIndex * 9;
    const faceData = stateString.slice(start, start + 9);
    faces[face] = [
      [faceData[0], faceData[1], faceData[2]],
      [faceData[3], faceData[4], faceData[5]],
      [faceData[6], faceData[7], faceData[8]],
    ];
  });
  
  return {
    faces,
    isScrambled: !isCubeSolved({ faces } as CubeState),
    isSolved: isCubeSolved({ faces } as CubeState),
  };
}
