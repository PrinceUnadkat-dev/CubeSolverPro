import { CubeState, Solution, SolutionStep, AlgorithmCase } from '@/types/cube';

export function getBeginnerSolution(state: CubeState): Solution {
  const steps: SolutionStep[] = [
    {
      phase: 'White Cross',
      moves: [
        { notation: 'F', description: 'Front face clockwise', face: 'front', direction: 'clockwise' },
        { notation: 'R', description: 'Right face clockwise', face: 'right', direction: 'clockwise' },
        { notation: 'U', description: 'Up face clockwise', face: 'top', direction: 'clockwise' },
        { notation: "R'", description: 'Right face counterclockwise', face: 'right', direction: 'counterclockwise' },
        { notation: "F'", description: 'Front face counterclockwise', face: 'front', direction: 'counterclockwise' },
      ],
      explanation: 'Create a white cross on the top face. Find white edge pieces and position them correctly.',
      algorithm: 'F R U R\' F\' (if white edge is in wrong position)'
    },
    {
      phase: 'White Corners',
      moves: [
        { notation: 'R', description: 'Right face clockwise', face: 'right', direction: 'clockwise' },
        { notation: 'U', description: 'Up face clockwise', face: 'top', direction: 'clockwise' },
        { notation: "R'", description: 'Right face counterclockwise', face: 'right', direction: 'counterclockwise' },
        { notation: "U'", description: 'Up face counterclockwise', face: 'top', direction: 'counterclockwise' },
      ],
      explanation: 'Complete the white face by positioning white corner pieces. Use the right-hand algorithm.',
      algorithm: 'R U R\' U\' (repeat 1-5 times until corner is correct)'
    },
    {
      phase: 'Middle Layer Edges',
      moves: [
        { notation: 'U', description: 'Up face clockwise', face: 'top', direction: 'clockwise' },
        { notation: 'R', description: 'Right face clockwise', face: 'right', direction: 'clockwise' },
        { notation: "U'", description: 'Up face counterclockwise', face: 'top', direction: 'counterclockwise' },
        { notation: "R'", description: 'Right face counterclockwise', face: 'right', direction: 'counterclockwise' },
        { notation: "U'", description: 'Up face counterclockwise', face: 'top', direction: 'counterclockwise' },
        { notation: "F'", description: 'Front face counterclockwise', face: 'front', direction: 'counterclockwise' },
        { notation: 'U', description: 'Up face clockwise', face: 'top', direction: 'clockwise' },
        { notation: 'F', description: 'Front face clockwise', face: 'front', direction: 'clockwise' },
      ],
      explanation: 'Position edge pieces in the middle layer. Two algorithms: right and left hand.',
      algorithm: 'Right: U R U\' R\' U\' F\' U F | Left: U\' L\' U L U F U\' F\''
    },
    {
      phase: 'Yellow Cross',
      moves: [
        { notation: 'F', description: 'Front face clockwise', face: 'front', direction: 'clockwise' },
        { notation: 'R', description: 'Right face clockwise', face: 'right', direction: 'clockwise' },
        { notation: 'U', description: 'Up face clockwise', face: 'top', direction: 'clockwise' },
        { notation: "R'", description: 'Right face counterclockwise', face: 'right', direction: 'counterclockwise' },
        { notation: "U'", description: 'Up face counterclockwise', face: 'top', direction: 'counterclockwise' },
        { notation: "F'", description: 'Front face counterclockwise', face: 'front', direction: 'counterclockwise' },
      ],
      explanation: 'Create a yellow cross on the top face. May need to repeat the algorithm 1-3 times.',
      algorithm: 'F R U R\' U\' F\' (FRUR\'U\'F\')'
    },
    {
      phase: 'Yellow Face',
      moves: [
        { notation: 'R', description: 'Right face clockwise', face: 'right', direction: 'clockwise' },
        { notation: 'U', description: 'Up face clockwise', face: 'top', direction: 'clockwise' },
        { notation: "R'", description: 'Right face counterclockwise', face: 'right', direction: 'counterclockwise' },
        { notation: 'U', description: 'Up face clockwise', face: 'top', direction: 'clockwise' },
        { notation: 'R', description: 'Right face clockwise', face: 'right', direction: 'clockwise' },
        { notation: 'U2', description: 'Up face double turn', face: 'top', direction: 'double' },
        { notation: "R'", description: 'Right face counterclockwise', face: 'right', direction: 'counterclockwise' },
      ],
      explanation: 'Complete the yellow face by orienting all yellow corner pieces.',
      algorithm: 'R U R\' U R U2 R\' (Sune algorithm)'
    },
    {
      phase: 'Position Yellow Corners',
      moves: [
        { notation: 'U', description: 'Up face clockwise', face: 'top', direction: 'clockwise' },
        { notation: 'R', description: 'Right face clockwise', face: 'right', direction: 'clockwise' },
        { notation: "U'", description: 'Up face counterclockwise', face: 'top', direction: 'counterclockwise' },
        { notation: "L'", description: 'Left face counterclockwise', face: 'left', direction: 'counterclockwise' },
        { notation: 'U', description: 'Up face clockwise', face: 'top', direction: 'clockwise' },
        { notation: "R'", description: 'Right face counterclockwise', face: 'right', direction: 'counterclockwise' },
        { notation: "U'", description: 'Up face counterclockwise', face: 'top', direction: 'counterclockwise' },
        { notation: 'L', description: 'Left face clockwise', face: 'left', direction: 'clockwise' },
      ],
      explanation: 'Position the yellow corner pieces in their correct locations.',
      algorithm: 'U R U\' L\' U R\' U\' L (repeat until corners are positioned)'
    },
    {
      phase: 'Position Yellow Edges',
      moves: [
        { notation: 'R', description: 'Right face clockwise', face: 'right', direction: 'clockwise' },
        { notation: 'U', description: 'Up face clockwise', face: 'top', direction: 'clockwise' },
        { notation: "R'", description: 'Right face counterclockwise', face: 'right', direction: 'counterclockwise' },
        { notation: 'F', description: 'Front face clockwise', face: 'front', direction: 'clockwise' },
        { notation: 'R', description: 'Right face clockwise', face: 'right', direction: 'clockwise' },
        { notation: 'U2', description: 'Up face double turn', face: 'top', direction: 'double' },
        { notation: "R'", description: 'Right face counterclockwise', face: 'right', direction: 'counterclockwise' },
        { notation: "U'", description: 'Up face counterclockwise', face: 'top', direction: 'counterclockwise' },
        { notation: 'R', description: 'Right face clockwise', face: 'right', direction: 'clockwise' },
        { notation: 'U', description: 'Up face clockwise', face: 'top', direction: 'clockwise' },
        { notation: "R'", description: 'Right face counterclockwise', face: 'right', direction: 'counterclockwise' },
        { notation: "F'", description: 'Front face counterclockwise', face: 'front', direction: 'counterclockwise' },
      ],
      explanation: 'Complete the cube by positioning the final edge pieces.',
      algorithm: 'R U R\' F R U2 R\' U\' R U R\' F\' (T-Perm)'
    }
  ];

  const totalMoves = steps.reduce((sum, step) => sum + step.moves.length, 0);

  return {
    method: 'beginner',
    steps,
    totalMoves,
    estimatedTime: totalMoves * 1.2, // Beginner method is slower
  };
}

// OLL (Orientation of Last Layer) algorithms
export const OLL_ALGORITHMS: AlgorithmCase[] = [
  {
    id: 'oll1',
    name: 'OLL 1 - Dot',
    pattern: 'No edges or corners oriented',
    algorithm: 'F R U R\' U\' F\' f R U R\' U\' f\'',
    difficulty: 'hard'
  },
  {
    id: 'oll21',
    name: 'OLL 21 - H',
    pattern: 'H shape on top',
    algorithm: 'F R U R\' U\' R F\' r U R\' U\' r\'',
    difficulty: 'medium'
  },
  {
    id: 'oll27',
    name: 'OLL 27 - Sune',
    pattern: 'Sune case',
    algorithm: 'R U R\' U R U2 R\'',
    difficulty: 'easy'
  },
  {
    id: 'oll26',
    name: 'OLL 26 - Anti-Sune',
    pattern: 'Anti-Sune case',
    algorithm: 'L\' U\' L U\' L\' U2 L',
    difficulty: 'easy'
  }
];

// PLL (Permutation of Last Layer) algorithms
export const PLL_ALGORITHMS: AlgorithmCase[] = [
  {
    id: 'pll_aa',
    name: 'Aa Perm',
    pattern: 'Adjacent corner swap',
    algorithm: 'x L2 D2 L\' U\' L D2 L\' U L\' x\'',
    difficulty: 'medium'
  },
  {
    id: 'pll_ab',
    name: 'Ab Perm',
    pattern: 'Adjacent corner swap (opposite)',
    algorithm: 'x\' L2 D2 L U L\' D2 L U\' L x',
    difficulty: 'medium'
  },
  {
    id: 'pll_t',
    name: 'T Perm',
    pattern: 'Adjacent edge swap',
    algorithm: 'R U R\' F\' R U R\' U\' R\' F R2 U\' R\'',
    difficulty: 'easy'
  },
  {
    id: 'pll_j',
    name: 'Ja Perm',
    pattern: 'Adjacent corner + edge swap',
    algorithm: 'x R2\' F R F\' R U2 r\' U r U2 x\'',
    difficulty: 'hard'
  }
];

// F2L (First Two Layers) algorithms
export const F2L_ALGORITHMS: AlgorithmCase[] = [
  {
    id: 'f2l_1',
    name: 'F2L Case 1',
    pattern: 'Corner and edge separated, both in top layer',
    algorithm: 'R U\' R\' F R F\'',
    difficulty: 'easy'
  },
  {
    id: 'f2l_2',
    name: 'F2L Case 2',
    pattern: 'Corner in bottom, edge in top',
    algorithm: 'F\' U F R U R\'',
    difficulty: 'easy'
  },
  {
    id: 'f2l_3',
    name: 'F2L Case 3',
    pattern: 'Edge and corner connected',
    algorithm: 'R U R\' U\' R U R\'',
    difficulty: 'medium'
  }
];

// CMLL (Corners of the Middle and Last Layer) for Roux
export const CMLL_ALGORITHMS: AlgorithmCase[] = [
  {
    id: 'cmll_o',
    name: 'CMLL O Case',
    pattern: 'All corners oriented',
    algorithm: 'R U R\' F\' R U R\' U\' R\' F R2 U\' R\'',
    difficulty: 'medium'
  },
  {
    id: 'cmll_h',
    name: 'CMLL H Case',
    pattern: 'H pattern with corners',
    algorithm: 'F R U\' R\' U\' R U R\' F\' R U R\' U\' R\' F R F\'',
    difficulty: 'hard'
  }
];

export function getAlgorithmsByMethod(method: string): AlgorithmCase[] {
  switch (method) {
    case 'cfop':
      return [...OLL_ALGORITHMS, ...PLL_ALGORITHMS, ...F2L_ALGORITHMS];
    case 'roux':
      return [...CMLL_ALGORITHMS];
    case 'beginner':
      return [
        {
          id: 'beginner_cross',
          name: 'Cross Algorithm',
          pattern: 'White edge placement',
          algorithm: 'F R U R\' F\'',
          difficulty: 'easy'
        },
        {
          id: 'beginner_corner',
          name: 'Corner Algorithm',
          pattern: 'White corner placement',
          algorithm: 'R U R\' U\'',
          difficulty: 'easy'
        },
        {
          id: 'beginner_middle',
          name: 'Middle Layer',
          pattern: 'Edge placement',
          algorithm: 'U R U\' R\' U\' F\' U F',
          difficulty: 'medium'
        }
      ];
    default:
      return [];
  }
}

export function findMatchingAlgorithm(cubeState: CubeState, method: string): AlgorithmCase | null {
  const algorithms = getAlgorithmsByMethod(method);
  
  // In a real implementation, you would analyze the cube state
  // and match it against known patterns
  
  // For now, return a random algorithm for demonstration
  if (algorithms.length > 0) {
    return algorithms[Math.floor(Math.random() * algorithms.length)];
  }
  
  return null;
}
