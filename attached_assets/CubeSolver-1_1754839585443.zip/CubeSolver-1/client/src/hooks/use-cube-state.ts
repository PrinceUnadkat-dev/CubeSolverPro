import { useState, useCallback, useEffect } from 'react';
import { CubeState, CubeColors, CubeMove, Solution, SolvingMethod, PlaybackState, DEFAULT_CUBE_COLORS } from '@/types/cube';
import { generateSolvedState, generateScrambledState, applyCubeMove, validateCubeState } from '@/lib/cube-state';
import { solveCube } from '@/lib/cube-solver';

export function useCubeState() {
  const [cubeState, setCubeState] = useState<CubeState>(() => generateSolvedState(DEFAULT_CUBE_COLORS));
  const [cubeColors, setCubeColors] = useState<CubeColors>(DEFAULT_CUBE_COLORS);
  const [solution, setSolution] = useState<Solution | null>(null);
  const [playbackState, setPlaybackState] = useState<PlaybackState>({
    isPlaying: false,
    currentStep: 0,
    currentMove: 0,
    speed: 1.0,
    showNotation: true,
    highlightMoves: true,
  });
  const [selectedFace, setSelectedFace] = useState<string | null>(null);
  const [isValidConfiguration, setIsValidConfiguration] = useState(true);

  // Validate cube configuration whenever colors change
  useEffect(() => {
    const isValid = validateCubeState(cubeState, cubeColors);
    setIsValidConfiguration(isValid);
  }, [cubeState, cubeColors]);

  const scrambleCube = useCallback(() => {
    const scrambledState = generateScrambledState(cubeColors);
    setCubeState(scrambledState);
    setSolution(null);
    setPlaybackState(prev => ({ ...prev, currentStep: 0, currentMove: 0, isPlaying: false }));
  }, [cubeColors]);

  const resetCube = useCallback(() => {
    const solvedState = generateSolvedState(cubeColors);
    setCubeState(solvedState);
    setSolution(null);
    setPlaybackState(prev => ({ ...prev, currentStep: 0, currentMove: 0, isPlaying: false }));
  }, [cubeColors]);

  const updateCubeColors = useCallback((newColors: CubeColors) => {
    setCubeColors(newColors);
    // Update cube state with new colors while maintaining configuration
    setCubeState(prev => {
      const newState = { ...prev };
      // Update center pieces with new colors
      Object.keys(newColors).forEach(face => {
        if (newState.faces[face as keyof typeof newState.faces]) {
          newState.faces[face as keyof typeof newState.faces][1][1] = newColors[face as keyof CubeColors];
        }
      });
      return newState;
    });
  }, []);

  const updateFaceColor = useCallback((face: keyof CubeColors, color: string) => {
    const newColors = { ...cubeColors, [face]: color };
    updateCubeColors(newColors);
  }, [cubeColors, updateCubeColors]);

  const solveCubeWithMethod = useCallback(async (method: SolvingMethod) => {
    if (!isValidConfiguration) {
      throw new Error('Invalid cube configuration. Please check your colors.');
    }

    try {
      const cubeSolution = await solveCube(cubeState, method);
      setSolution(cubeSolution);
      setPlaybackState(prev => ({ ...prev, currentStep: 0, currentMove: 0, isPlaying: false }));
      return cubeSolution;
    } catch (error) {
      console.error('Error solving cube:', error);
      throw error;
    }
  }, [cubeState, isValidConfiguration]);

  const applyMove = useCallback((move: CubeMove) => {
    const newState = applyCubeMove(cubeState, move);
    setCubeState(newState);
  }, [cubeState]);

  const nextMove = useCallback(() => {
    if (!solution || playbackState.currentStep >= solution.steps.length) return;

    const currentStep = solution.steps[playbackState.currentStep];
    if (playbackState.currentMove >= currentStep.moves.length) {
      // Move to next step
      setPlaybackState(prev => ({
        ...prev,
        currentStep: prev.currentStep + 1,
        currentMove: 0,
      }));
      return;
    }

    const move = currentStep.moves[playbackState.currentMove];
    applyMove(move);
    setPlaybackState(prev => ({
      ...prev,
      currentMove: prev.currentMove + 1,
    }));
  }, [solution, playbackState, applyMove]);

  const previousMove = useCallback(() => {
    if (!solution || (playbackState.currentStep === 0 && playbackState.currentMove === 0)) return;

    if (playbackState.currentMove > 0) {
      setPlaybackState(prev => ({
        ...prev,
        currentMove: prev.currentMove - 1,
      }));
    } else if (playbackState.currentStep > 0) {
      const prevStep = solution.steps[playbackState.currentStep - 1];
      setPlaybackState(prev => ({
        ...prev,
        currentStep: prev.currentStep - 1,
        currentMove: prevStep.moves.length - 1,
      }));
    }

    // TODO: Implement undo move logic by reversing the move
  }, [solution, playbackState]);

  const togglePlayback = useCallback(() => {
    setPlaybackState(prev => ({ ...prev, isPlaying: !prev.isPlaying }));
  }, []);

  const updatePlaybackSettings = useCallback((settings: Partial<PlaybackState>) => {
    setPlaybackState(prev => ({ ...prev, ...settings }));
  }, []);

  // Auto-playback when playing
  useEffect(() => {
    if (!playbackState.isPlaying || !solution) return;

    const interval = setInterval(() => {
      nextMove();
    }, 1000 / playbackState.speed);

    return () => clearInterval(interval);
  }, [playbackState.isPlaying, playbackState.speed, solution, nextMove]);

  const getCurrentMove = useCallback(() => {
    if (!solution || playbackState.currentStep >= solution.steps.length) return null;
    
    const currentStep = solution.steps[playbackState.currentStep];
    if (playbackState.currentMove >= currentStep.moves.length) return null;
    
    return currentStep.moves[playbackState.currentMove];
  }, [solution, playbackState]);

  const getProgress = useCallback(() => {
    if (!solution) return { current: 0, total: 0, percentage: 0 };
    
    let totalMoves = 0;
    let currentMoves = 0;
    
    solution.steps.forEach((step, stepIndex) => {
      totalMoves += step.moves.length;
      if (stepIndex < playbackState.currentStep) {
        currentMoves += step.moves.length;
      } else if (stepIndex === playbackState.currentStep) {
        currentMoves += playbackState.currentMove;
      }
    });
    
    return {
      current: currentMoves,
      total: totalMoves,
      percentage: totalMoves > 0 ? (currentMoves / totalMoves) * 100 : 0,
    };
  }, [solution, playbackState]);

  return {
    cubeState,
    cubeColors,
    solution,
    playbackState,
    selectedFace,
    isValidConfiguration,
    scrambleCube,
    resetCube,
    updateCubeColors,
    updateFaceColor,
    solveCubeWithMethod,
    applyMove,
    nextMove,
    previousMove,
    togglePlayback,
    updatePlaybackSettings,
    setSelectedFace,
    getCurrentMove,
    getProgress,
  };
}
