import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { useIsMobile } from '@/hooks/use-mobile';
import { ModeToggle } from '@/components/ui/mode-toggle';
import { ThreeCube } from '@/components/cube/ThreeCube';
import { ColorPicker } from '@/components/cube/ColorPicker';
import { MethodSelector } from '@/components/cube/MethodSelector';
import { PlaybackControls } from '@/components/cube/PlaybackControls';
import { SolutionSteps } from '@/components/cube/SolutionSteps';
import { AlgorithmCard } from '@/components/cube/AlgorithmCard';
import { useCubeState } from '@/hooks/use-cube-state';
import { SolvingMethod, AppMode } from '@/types/cube';
import { getAlgorithmsByMethod, findMatchingAlgorithm } from '@/lib/cube-algorithms';
import { cn } from '@/lib/utils';

export default function CubeAssistant() {
  const [mode, setMode] = useState<AppMode>('solve');
  const [selectedMethod, setSelectedMethod] = useState<SolvingMethod>('beginner');
  const [isSolving, setIsSolving] = useState(false);
  const isMobile = useIsMobile();
  const { toast } = useToast();

  const {
    cubeState,
    cubeColors,
    solution,
    playbackState,
    selectedFace,
    isValidConfiguration,
    scrambleCube,
    resetCube,
    updateCubeColors,
    updateFaceColor,
    solveCubeWithMethod,
    nextMove,
    previousMove,
    togglePlayback,
    updatePlaybackSettings,
    setSelectedFace,
    getCurrentMove,
    getProgress,
  } = useCubeState();

  const currentMove = getCurrentMove();
  const progress = getProgress();
  const currentAlgorithm = mode === 'learn' ? findMatchingAlgorithm(cubeState, selectedMethod) : null;
  const availableAlgorithms = mode === 'learn' ? getAlgorithmsByMethod(selectedMethod) : [];

  // Handle solve cube
  const handleSolveCube = async () => {
    if (!isValidConfiguration) {
      toast({
        title: "Invalid Configuration",
        description: "Please ensure all faces have different colors before solving.",
        variant: "destructive",
      });
      return;
    }

    setIsSolving(true);
    try {
      await solveCubeWithMethod(selectedMethod);
      toast({
        title: "Solution Generated",
        description: `${selectedMethod.toUpperCase()} solution ready with ${progress.total} moves.`,
      });
    } catch (error) {
      toast({
        title: "Solving Failed",
        description: error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive",
      });
    } finally {
      setIsSolving(false);
    }
  };

  // Handle scramble
  const handleScramble = () => {
    scrambleCube();
    toast({
      title: "Cube Scrambled",
      description: "Ready for solving!",
    });
  };

  // Handle reset
  const handleReset = () => {
    resetCube();
    toast({
      title: "Cube Reset",
      description: "Cube returned to solved state.",
    });
  };

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if user is typing in an input
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }

      switch (e.key.toLowerCase()) {
        case 'arrowright':
        case ' ':
          e.preventDefault();
          nextMove();
          break;
        case 'arrowleft':
          e.preventDefault();
          previousMove();
          break;
        case 's':
          e.preventDefault();
          handleSolveCube();
          break;
        case 'r':
          e.preventDefault();
          handleScramble();
          break;
        case 'h':
          e.preventDefault();
          toast({
            title: "Keyboard Shortcuts",
            description: "Space/→: Next move, ←: Previous move, S: Solve, R: Scramble, H: Help",
          });
          break;
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [nextMove, previousMove, handleSolveCube, handleScramble, toast]);

  // Check if cube is solved
  const isCubeSolved = solution && progress.current === progress.total;

  return (
    <div className="min-h-screen bg-dark-primary text-foreground">
      {/* Header */}
      <header className="bg-dark-secondary border-b border-border py-3">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-br from-accent-cyan to-accent-purple rounded-lg flex items-center justify-center">
                <i className="fas fa-cube text-white text-lg" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">CubeMate</h1>
                <p className="text-xs text-muted-foreground">Rubik's Cube Assistant</p>
              </div>
            </div>
            <ModeToggle mode={mode} onModeChange={setMode} />
          </div>
        </div>
      </header>

      {isCubeSolved ? (
        // Completion Screen with Statistics
        <main className="container mx-auto px-4 py-8">
          <div className="max-w-2xl mx-auto text-center space-y-6">
            {/* Success Message */}
            <div className="bg-green-500/20 border border-green-500/40 rounded-lg p-6">
              <div className="text-4xl mb-2">🎉</div>
              <h2 className="text-2xl font-bold text-green-400 mb-2">Cube Solved!</h2>
              <p className="text-muted-foreground">
                Congratulations! You completed the solution using the {selectedMethod.toUpperCase()} method.
              </p>
            </div>
            
            {/* Statistics Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="bg-dark-secondary border-border">
                <CardContent className="p-4 text-center">
                  <div className="text-3xl font-bold text-accent-cyan mb-1">{progress.total}</div>
                  <div className="text-sm text-muted-foreground">Total Moves</div>
                </CardContent>
              </Card>
              <Card className="bg-dark-secondary border-border">
                <CardContent className="p-4 text-center">
                  <div className="text-3xl font-bold text-accent-purple mb-1">{selectedMethod.toUpperCase()}</div>
                  <div className="text-sm text-muted-foreground">Method Used</div>
                </CardContent>
              </Card>
              <Card className="bg-dark-secondary border-border">
                <CardContent className="p-4 text-center">
                  <div className="text-3xl font-bold text-accent-mint mb-1">{Math.round(solution?.estimatedTime || 0)}s</div>
                  <div className="text-sm text-muted-foreground">Estimated Time</div>
                </CardContent>
              </Card>
            </div>
            
            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                onClick={handleReset}
                className="bg-accent-cyan hover:bg-accent-cyan/90 text-dark-primary font-semibold px-8 py-3"
                size="lg"
              >
                <i className="fas fa-redo mr-2" />
                Solve Another Cube
              </Button>
              <Button 
                onClick={handleScramble}
                variant="outline"
                className="border-accent-orange text-accent-orange hover:bg-accent-orange hover:text-dark-primary px-8 py-3"
                size="lg"
              >
                <i className="fas fa-random mr-2" />
                New Scramble
              </Button>
            </div>

            {/* Solution Review */}
            <Card className="bg-dark-secondary border-border">
              <CardHeader>
                <CardTitle className="text-lg text-foreground">Solution Review</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="max-h-48 overflow-y-auto">
                  {solution?.steps.map((step, index) => (
                    <div key={index} className="py-2 border-b border-border last:border-b-0">
                      <div className="flex justify-between items-center">
                        <span className="font-medium text-accent-cyan">{step.phase}</span>
                        <span className="text-sm text-muted-foreground">{step.moves.length} moves</span>
                      </div>
                      <div className="text-sm text-muted-foreground mt-1">{step.explanation}</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      ) : (
        // Main Interface - Compact MCQ-style layout
        <main className="container mx-auto px-4 py-6">
          <div className="max-w-6xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
              {/* Left Sidebar - Controls */}
              <div className="lg:col-span-1 space-y-4">
                <ColorPicker
                  colors={cubeColors}
                  onColorsChange={updateCubeColors}
                  selectedFace={selectedFace}
                  onFaceSelect={setSelectedFace}
                  isValid={isValidConfiguration}
                />

                <Card className="bg-dark-secondary border-border">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm text-foreground">Step 2: Choose Method</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <MethodSelector
                      selectedMethod={selectedMethod}
                      onMethodChange={setSelectedMethod}
                      mode={mode}
                    />
                  </CardContent>
                </Card>

                <Card className="bg-dark-secondary border-border">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm text-foreground">Step 3: Solve</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button
                      onClick={handleSolveCube}
                      disabled={isSolving || !isValidConfiguration}
                      className="w-full bg-accent-cyan hover:bg-accent-cyan/90 text-dark-primary font-semibold"
                    >
                      {isSolving ? (
                        <>
                          <i className="fas fa-spinner fa-spin mr-2" />
                          Solving...
                        </>
                      ) : (
                        <>
                          <i className="fas fa-play mr-2" />
                          Solve Cube
                        </>
                      )}
                    </Button>

                    <div className="grid grid-cols-2 gap-2">
                      <Button
                        variant="outline"
                        onClick={handleScramble}
                        size="sm"
                        className="text-xs"
                      >
                        <i className="fas fa-random mr-1" />
                        Scramble
                      </Button>
                      <Button
                        variant="outline"
                        onClick={handleReset}
                        size="sm"
                        className="text-xs"
                      >
                        <i className="fas fa-undo mr-1" />
                        Reset
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Quick Stats */}
                <Card className="bg-dark-secondary border-border">
                  <CardContent className="p-3">
                    <div className="text-xs space-y-1">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Status:</span>
                        <span className={cn(
                          "font-medium",
                          cubeState.isSolved ? "text-accent-mint" : "text-accent-coral"
                        )}>
                          {cubeState.isSolved ? 'Solved' : cubeState.isScrambled ? 'Scrambled' : 'Ready'}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Progress:</span>
                        <span className="text-accent-cyan font-medium">{progress.current}/{progress.total}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Method:</span>
                        <span className="text-accent-purple font-medium">{selectedMethod.toUpperCase()}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Center - 3D Cube */}
              <div className="lg:col-span-2">
                <Card className="bg-dark-secondary border-border">
                  <CardContent className="p-4">
                    <div className="aspect-square max-w-lg mx-auto">
                      <ThreeCube
                        cubeState={cubeState}
                        onFaceClick={setSelectedFace}
                        highlightMove={playbackState.highlightMoves ? currentMove : null}
                        className="w-full h-full"
                      />
                    </div>
                  </CardContent>
                </Card>

                {/* Algorithm Display (Learn Mode) */}
                {mode === 'learn' && currentAlgorithm && (
                  <div className="mt-4">
                    <AlgorithmCard
                      algorithm={currentAlgorithm}
                      isActive={true}
                      onSelect={() => {}}
                    />
                  </div>
                )}
              </div>

              {/* Right Sidebar - Solution Steps */}
              <div className="lg:col-span-1">
                {solution ? (
                  <div className="space-y-4">
                    <PlaybackControls
                      playbackState={playbackState}
                      onPlaybackChange={updatePlaybackSettings}
                      onNextMove={nextMove}
                      onPreviousMove={previousMove}
                      onTogglePlay={togglePlayback}
                      currentMove={currentMove}
                      progress={progress}
                      mode={mode}
                    />

                    <SolutionSteps
                      solution={solution}
                      playbackState={playbackState}
                      mode={mode}
                      onStepSelect={(stepIndex) => updatePlaybackSettings({ currentStep: stepIndex, currentMove: 0 })}
                      onMoveSelect={(stepIndex, moveIndex) => updatePlaybackSettings({ currentStep: stepIndex, currentMove: moveIndex })}
                    />
                  </div>
                ) : (
                  <Card className="bg-dark-secondary border-border">
                    <CardContent className="p-4 text-center">
                      <div className="text-muted-foreground text-sm">
                        <i className="fas fa-info-circle mb-2 text-lg block" />
                        Set up your cube colors and click solve to see the solution steps here.
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Algorithm Library (Learn Mode) */}
                {mode === 'learn' && availableAlgorithms.length > 0 && (
                  <Card className="bg-dark-secondary border-border mt-4">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm text-foreground">
                        {selectedMethod.toUpperCase()} Algorithms
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-3">
                      <div className="space-y-2 max-h-64 overflow-y-auto">
                        {availableAlgorithms.slice(0, 8).map((algorithm, index) => (
                          <div key={index} className="p-2 bg-muted/20 rounded text-xs">
                            <div className="font-medium text-accent-cyan">{algorithm.name}</div>
                            <div className="text-muted-foreground">{algorithm.algorithm}</div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>
          </div>
        </main>
      )}
    </div>
  );
}
