# CubeMate - Rubik's Cube Assistant

A visually stunning, client-side Rubik's Cube solving assistant with 3D visualization, multiple solving methods, and interactive learning features. Built with Three.js, React, and modern web technologies.

![CubeMate Preview](https://via.placeholder.com/800x400/0f0f23/00d4ff?text=CubeMate+Preview)

## 🌟 Features

### 🎯 Solving Modes
- **Solve Mode**: Clean, distraction-free solving interface
- **Learn Mode**: Educational content with algorithms and detailed explanations

### 🎮 3D Cube Visualization
- Realistic Three.js rendering with shadows and lighting
- Interactive orbit controls (drag to rotate, scroll to zoom)
- Click to select cube faces for color customization
- Smooth move animations with highlighting

### 🎨 Advanced Color Picker
- Visual unfolded cube preview
- Preset color schemes (Classic, Neon, Pastel)
- Custom color palette with live preview
- Drag-and-drop or click-to-apply color assignment
- Real-time validation of cube configuration

### 🧮 Multiple Solving Methods
- **Beginner Method**: Layer-by-layer approach (50-100 moves)
- **CFOP**: Cross, F2L, OLL, PLL (50-60 moves)
- **Roux**: Block building approach (45-50 moves)
- **ZZ**: Edge orientation first (50-55 moves)
- **Kociemba**: Optimal computer solution (19-25 moves)

### ⚡ Playback System
- **Manual Mode**: Step-through moves one at a time
- **Auto Mode**: Automated playback with speed control
- Progress tracking with visual indicators
- Move notation display (toggleable)
- Highlight affected pieces during moves
- Undo/redo functionality

### 📚 Learning Features
- Algorithm library with 50+ cubing algorithms
- Step-by-step tutorials for each method
- Phase-by-phase explanations
- Formula cards with beautiful formatting
- Difficulty ratings and move counts
- Pattern recognition guides

### 📱 Mobile Support
- Responsive design for all screen sizes
- Touch gesture support for cube rotation
- Mobile-optimized bottom controls
- Swipe navigation for solution steps

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ 
- npm or yarn

### Local Development

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/cubemate.git
   cd cubemate
   ```

2. **Install dependencies**
   ```bash
   npm install
   